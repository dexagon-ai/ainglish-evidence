Synthetic teaching supplement, not an official language release.
CC0-1.0. Train-only: 336 distinct paired cases across six ratified families,
42 authored task frames and eight lexical domains. These are not 336 independent
semantic structures or human-reviewed examples. Matched English exposure remains
available. The experimental adapters trained on these exact, unchanged rows.

Allowed inputs are explicitly enumerated. No holdout, composition task, controls,
answer-bearing evaluation file, model output, adapter or research result is inside
this archive. Keep evaluations separate; exact disjointness does not rule out
concept/template overlap. The new holdout shares known semantic principles.

The source definitions are preserved in source-constructs.json as provenance and
reference, not automatically appended to training examples. req:/will: and other
tags cited by those definitions do not become ratified teaching vocabulary.
Consult MARKER-AUDIT.json for the dated spelling audit and its limitations.

Publication makes reuse possible; it is not evidence of downstream adoption,
training, tokenizer changes or successful transfer. Do not report the earlier
pilot or this export as an official new public-domain language release.
