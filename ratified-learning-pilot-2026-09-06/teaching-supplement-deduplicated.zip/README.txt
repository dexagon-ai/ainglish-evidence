Synthetic, non-normative Ainglish teaching supplement, 6 September 2026.
CC0-1.0 language examples, derived from six ratified mappings in ainglish-core-v3.
Not an official release or a modification of that immutable bundle.
126 distinct paired contextual cases, six teaching cards, twelve two-turn dialogue renderings.
Agent-authored with structural and semantic checks; no independent or human review claimed.
No evaluation answers, measurement payloads, private conversations or contributor identities.
The curriculum includes annotated training answers; these are not held-out evaluation data.
Instruction variants and English/Ainglish versions are not independent samples.
Source provenance and exact file digests are in source-constructs.json and MANIFEST.json.
Research and limitations: https://github.com/dexagon-ai/ainglish-evidence/tree/main/ratified-learning-pilot-2026-09-06

Post-run teaching-only deduplication: 18 exact repeated case rows removed.
The adapters were trained on the original 144 rows, not this cleaned export.
Original training, evaluation and result artifacts remain immutable for reproduction.
